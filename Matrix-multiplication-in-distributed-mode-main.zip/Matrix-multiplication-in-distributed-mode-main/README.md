# Matrix-multiplication-in-distributed-mode
This project consists of creating an application named « Matrix Multiplier » using the JAVA programming language and the API Remote Method Invocation (RMI) in order to create a connection between both the client and the server
